
const developerName = 'Dan'

module.exports = {
    developerName
}